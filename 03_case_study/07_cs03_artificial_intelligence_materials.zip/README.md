# ShopEase Philippines Synthetic RAG + Agent Dataset

This is a fictional, synthetic dataset created for the Analytics Solutions Bootcamp.

## Files

| File | Format | Purpose |
|---|---|---|
| company_handbook.pdf | PDF | Employee and company policies |
| return_refund_policy.docx | DOCX | Return, refund, exchange and warranty rules |
| product_catalog.csv | CSV | Product master data |
| orders.xlsx | XLSX | Transaction/order data |
| customers.json | JSON | Customer master data |
| shipping_policy.md | Markdown | Shipping fees, timelines and free-shipping rules |
| support_tickets.json | JSON | Customer support cases linked to orders |
| promotions.txt | TXT | September 2026 promotions |
| stores.csv | CSV | Store master data |
| store_inventory.csv | CSV | Store-level stock by SKU |
| faq.html | HTML | Frequently asked questions |

## Key Relationships

- `customers.customer_id` -> `orders.customer_id`
- `orders.sku` -> `product_catalog.sku`
- `orders.fulfillment_store_id` -> `stores.store_id`
- `store_inventory.store_id` -> `stores.store_id`
- `store_inventory.sku` -> `product_catalog.sku`
- `support_tickets.order_id` -> `orders.order_id`
- `support_tickets.customer_id` -> `customers.customer_id`

## Useful Demonstration Record

`CUST-001` has order `ORD-1025` for `SKU-0042`.

- The order was delivered on 2026-08-28.
- Ticket `TKT-5001` reports the item as damaged.
- The Return and Refund Policy contains the applicable damaged-item rules.
- `SKU-0042` has store-level inventory records that can be queried.

This gives learners a compact multi-tool / cross-file scenario.

## Example RAG Questions

1. How many days does a customer have for a standard return?
2. What should a customer provide when reporting a damaged item?
3. Are Gold members eligible for free shipping?
4. How long do approved refunds normally take?
5. Are opened Personal Care products returnable?
6. What does the company handbook say about giving AI systems authority to issue refunds?

## Example Agent Questions

1. What product did CUST-001 purchase in ORD-1025?
2. Is ORD-1025 within the damaged-item reporting window as of 2026-09-02?
3. Which stores currently have SKU-0042 in stock?
4. Find CUST-001's order, identify the product, retrieve the applicable return rule, and summarize what Customer Support should tell them.
5. Determine whether a given customer's order qualifies for free shipping based on membership tier and order amount.
6. Check a warranty concern by combining the order, product warranty period, delivery date, and support ticket.

## Suggested Agent Tools

```python
get_customer(customer_id)
get_order(order_id)
get_product(sku)
get_store(store_id)
check_inventory(sku)
get_support_tickets(customer_id=None, order_id=None)
search_policy(question)
```

For teaching purposes, keep actions such as `cancel_order()` or `issue_refund()` simulated or read-only unless you are specifically demonstrating human confirmation, permissions, and audit controls.
