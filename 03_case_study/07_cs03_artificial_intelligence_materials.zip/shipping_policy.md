# ShopEase Philippines Shipping Policy

**Effective date:** 1 August 2026

## Standard Delivery

- Metro Manila: 1-3 business days
- Major provincial cities: 3-5 business days
- Other serviceable areas: 5-8 business days

## Shipping Fees

Standard shipping costs **PHP 99** per order.

Shipping is free when either of the following applies:

1. The order's net merchandise amount is at least **PHP 2,500**; or
2. The customer is a **Gold** member.

Silver and Basic members follow the normal PHP 2,500 free-shipping threshold.

## Failed Delivery

The courier may attempt delivery up to two times. If both attempts fail because the customer is unavailable, the order may be returned to the fulfillment store.

## Tracking

Tracking information becomes available after an order changes to `Shipped`.

## Service Limitations

Delivery times are estimates and may be affected by weather, holidays, courier disruptions, or remote-area handling.
